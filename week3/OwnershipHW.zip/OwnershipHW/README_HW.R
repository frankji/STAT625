#
# Due Thursday, September 22, 9 AM
#
# Fix up the challenge script so it works.  Then check to see whether
# it matches the results from other script for these sample properties.
# We haven't done this, so it may or may not.
#
# Upload your revised challenge script to the Dropbox.com folder.

